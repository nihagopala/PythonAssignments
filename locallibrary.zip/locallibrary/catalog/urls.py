# Use include() to add URLS from the catalog application
from django.conf.urls import include
from django.conf.urls import url
from . import views
urlpatterns = [
    #url(r'^catalog/', include('catalog.urls')),
    url(r'^$', views.index, name='index'),
    url(r'^books/$', views.BookListView.as_view(), name='books'),
    url(r'^book/(?P<pk>\d+)$', views.BookDetailView.as_view(), name='book-detail'),
    url(r'^mybooks/$', views.LoanedBooksByUserListView.as_view(), name='my-borrowed'),
]